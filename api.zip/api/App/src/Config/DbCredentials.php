<?php 

define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "Webdev@26");
define("DB_NAME", "mini_ecommerce_app");

// define("DB_HOST", "sql301.infinityfree.com");
// define("DB_USER", "if0_39159318");
// define("DB_PASS", "GWn46Z9Ga6Vb");
// define("DB_NAME", "if0_39159318_mini_ecommerce_app");
