<?php 

//Local DB
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "Webdev@26");
define("DB_NAME", "mini_ecommerce_app");

//Live DB
// define("DB_HOST", "sql212.infinityfree.com");
// define("DB_USER", "if0_39160587");
// define("DB_PASS", "Yua5AfEL7OO0e");
// define("DB_NAME", "if0_39160587_scandiweb_db");
