<?php

namespace App\Controller\Attributes;

abstract class AttributesController 
{
    abstract public function attributeType($id);
}